CKEDITOR.plugins.setLang('layoutmanager', 'bg', {
    title: 'Оформление',
    addLayoutDialogTitle: 'Избери шаблон',
    manageLayoutDialogTitle: 'Замени с',
    removeLayoutMenuLabel: 'Премахни шаблон',
    manageLayoutMenuLabel: 'Замени шаблон'


});
