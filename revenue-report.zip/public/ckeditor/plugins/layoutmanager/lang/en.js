CKEDITOR.plugins.setLang('layoutmanager', 'en', {
    title: 'Layouts',
    addLayoutDialogTitle: 'Choose layout',
    manageLayoutDialogTitle: 'Replace layout with',
    removeLayoutMenuLabel: 'Remove layout',
    manageLayoutMenuLabel: 'Replace layout'
});
