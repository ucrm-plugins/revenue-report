/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'codemirror', 'bg', {
	toolbar: 'Код',
	searchCode: 'Търси в кода',
	autoFormat: 'Форматирай избраното',
	commentSelectedRange: 'Коментирай избраното',
	uncommentSelectedRange: 'Откоментирай избраното',
	autoCompleteToggle: 'Активирай/деактивирай авто довършване за HTML тагове'
});
