/**
 * @fileOverview Definition for token plugin dialog.
 *
 */

'use strict';

CKEDITOR.dialog.add( "token", function( editor ) {
	let lang = editor.lang.token;
	let	generalLabel = editor.lang.common.generalTab;
	let tokens = [["",""]];

	if (typeof editor.config.availableTokens != "undefined") {
		tokens = editor.config.availableTokens;
	}

	return {
		title: lang.title,
		resizable: CKEDITOR.DIALOG_RESIZE_NONE,
		minWidth: 300,
		minHeight: 60,
		contents: [
			{
				id: "variable",
				label: "Variable",
				title: "Variable",
				elements: [
					{
						id: "name",
						type: "select",
						label: lang.name,
						required: true,
						items: tokens,
						setup: function( widget ) {
							this.setValue( widget.data.name );
						},
						commit: function( widget ) {
							widget.setData( 'name', this.getValue() );
						},
						onChange: function( api ) {
							// this = CKEDITOR.ui.dialog.select
							// Runs on first display also!

							//alert( 'Current value: ' + this.getValue() );
						}
					}

				]
			}




		]
	};
} );
