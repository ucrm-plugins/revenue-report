CKEDITOR.plugins.setLang( 'token', 'en', {
	title: "Twig Token",
	toolbar: "Twig Token",
	name: "Variable",
	pathName: "token"
} );
