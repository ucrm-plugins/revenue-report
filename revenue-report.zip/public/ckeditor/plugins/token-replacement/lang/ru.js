CKEDITOR.plugins.setLang( 'token', 'ru', {
	title: 'Вставить токен',
	toolbar: 'Токен',
	name: 'Токен',
	pathName: 'token'
} );
