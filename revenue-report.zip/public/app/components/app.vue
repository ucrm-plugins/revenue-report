<template>
    <p>Hello World!</p>



</template>


<script>
module.exports = {
    data: function() {
        return {
            message: 'Testing!'
        }
    }

}
</script>


<style>



</style>